// toggle menu

document.querySelector('.navbar').addEventListener('click', () => {
  document.querySelector('.list').classList.toggle('show');
});
