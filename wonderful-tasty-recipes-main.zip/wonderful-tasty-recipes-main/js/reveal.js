// scroll reveal

ScrollReveal().reveal('.main', { delay: 1000 });
ScrollReveal().reveal('.list', { delay: 1000 });
