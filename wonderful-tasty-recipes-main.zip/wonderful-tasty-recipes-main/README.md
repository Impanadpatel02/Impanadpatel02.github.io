# Wonderful Tasty Recipes

This project consists of a recipe collection website for practicing the basics of HTML, CSS and JavaScript skills.
